package org.thechiselgroup.choosel.visualization_component.heat_bars.client;

import java.util.ArrayList;
import java.util.List;

import org.thechiselgroup.choosel.core.client.resources.DataType;
import org.thechiselgroup.choosel.core.client.resources.DefaultResourceSetFactory;
import org.thechiselgroup.choosel.core.client.resources.Resource;
import org.thechiselgroup.choosel.core.client.resources.ResourceSet;
import org.thechiselgroup.choosel.core.client.resources.ResourceSetFactory;
import org.thechiselgroup.choosel.core.client.ui.Color;
import org.thechiselgroup.choosel.core.client.views.model.DefaultViewItem;
import org.thechiselgroup.choosel.core.client.views.model.SlotMappingConfiguration;
import org.thechiselgroup.choosel.core.client.views.model.ViewItem;
import org.thechiselgroup.choosel.core.client.views.model.ViewItemInteraction;
import org.thechiselgroup.choosel.core.client.views.model.ViewItemInteractionHandler;
import org.thechiselgroup.choosel.core.client.views.resolvers.FirstResourcePropertyResolver;
import org.thechiselgroup.choosel.core.client.views.resolvers.FixedValueResolver;
import org.thechiselgroup.choosel.core.client.views.resolvers.HeatBarsSliceValueListResolver;
import org.thechiselgroup.choosel.visualization_component.chart.client.ChartWidget;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class HeatBarsEntryPoint implements EntryPoint {
    private String labelProperty;

    /**
     * This is the entry point method.
     */
    public void onModuleLoad() {

        HeatBars heatBars = new HeatBars();
        int chartHeight = 250;
        int chartWidth = 1000;
        heatBars.initChartDimensions(chartHeight, chartWidth);
        for (ViewItem viewItem : createTestViewItems()) {
            heatBars.addViewItem(viewItem);
        }
        ChartWidget widget = (ChartWidget) heatBars.createWidget();
        widget.setHeight(chartHeight + 100 + "px");
        widget.setWidth(chartWidth + 100 + "px");

        VerticalPanel panel = new VerticalPanel();
        panel.add(widget);

        RootPanel.get("entryPoint").add(panel);

    }

    // TODO delete me
    // each view Item should represent a bar
    public List<ViewItem> createTestViewItems() {
        List<ViewItem> viewItems = new ArrayList<ViewItem>();
        ResourceSetFactory factory = new DefaultResourceSetFactory();
        labelProperty = "label-property";

        for (int i = 0; i < 5; i++) {
            ResourceSet resources = generateFakeResourceSet(factory, i);
            SlotMappingConfiguration configuration = new SlotMappingConfiguration();

            configuration.setResolver(HeatBars.ZERO_COLOR,
                    new FixedValueResolver(new Color("#ffffff"),
                            "Fixed-Color-White"));
            configuration.setResolver(HeatBars.LOW_COLOR,
                    new FixedValueResolver(new Color("#ffaaaa"),
                            "Fixed-Color-Light-Pink"));
            configuration.setResolver(HeatBars.MIDDLE_COLOR,
                    new FixedValueResolver(new Color("#f55555"),
                            "Fixed-Color-Dark-Pink"));
            configuration.setResolver(HeatBars.HIGH_COLOR,
                    new FixedValueResolver(new Color("#ff0000"),
                            "Fixed-Color-Red"));
            configuration.setResolver(HeatBars.LABEL,
                    new FirstResourcePropertyResolver("HeatBarsLabelResolver",
                            labelProperty, DataType.TEXT));
            configuration.setResolver(HeatBars.BINNING_VALUE,
                    new HeatBarsSliceValueListResolver("binVal"));

            ViewItemInteractionHandler handler = new ViewItemInteractionHandler() {
                @Override
                public void onInteraction(ViewItem viewItem,
                        ViewItemInteraction interaction) {
                }
            };
            viewItems.add(new DefaultViewItem("ID" + i, resources,
                    configuration, handler));
        }
        return viewItems;
    }

    public ResourceSet generateFakeResourceSet(ResourceSetFactory factory,
            int index) {
        ResourceSet resources = factory.createResourceSet();

        int numDataPerBar = 3000;

        for (int i = 0; i < numDataPerBar; i++) {
            Resource resource = new Resource("uri:" + index * numDataPerBar + i);
            resource.putValue("binVal", Math.random() * 100);
            resource.putValue(labelProperty, "Bar #" + index);
            resources.add(resource);
        }
        return resources;
    }
}
